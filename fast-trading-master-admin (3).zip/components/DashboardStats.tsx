import React from 'react';
import { User, Agent, Transaction } from '../types';
import { Users, UserCog, Wallet, ArrowUpCircle } from 'lucide-react';

interface Props {
  users: User[];
  agents: Agent[];
  transactions: Transaction[];
}

const StatCard = ({ title, value, icon, color }: { title: string; value: string | number; icon: React.ReactNode; color: string }) => (
  <div className="bg-white p-6 rounded-lg shadow-md flex items-center space-x-4 border-l-4" style={{ borderColor: color }}>
    <div className={`p-3 rounded-full text-white`} style={{ backgroundColor: color }}>
      {icon}
    </div>
    <div>
      <p className="text-gray-500 text-sm font-medium">{title}</p>
      <h3 className="text-2xl font-bold text-gray-800">{value}</h3>
    </div>
  </div>
);

const DashboardStats: React.FC<Props> = ({ users, agents, transactions }) => {
  const pendingWithdrawals = transactions.filter(t => t.type === 'withdraw' && t.status === 'pending').length;
  const totalUserBalance = users.reduce((acc, user) => acc + user.balance, 0);

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
      <StatCard 
        title="মোট ইউজার" 
        value={users.length} 
        icon={<Users size={24} />} 
        color="#3B82F6" 
      />
      <StatCard 
        title="মোট সাব-এজেন্ট" 
        value={agents.length} 
        icon={<UserCog size={24} />} 
        color="#8B5CF6" 
      />
      <StatCard 
        title="পেন্ডিং উইথড্র" 
        value={pendingWithdrawals} 
        icon={<ArrowUpCircle size={24} />} 
        color="#EF4444" 
      />
      <StatCard 
        title="ইউজার মোট ব্যালেন্স ($)" 
        value={totalUserBalance.toFixed(2)} 
        icon={<Wallet size={24} />} 
        color="#10B981" 
      />
    </div>
  );
};

export default DashboardStats;