import React, { useState, useEffect } from 'react';
import { ShieldCheck, Activity, Lock, Delete, ArrowLeft } from 'lucide-react';

interface Props {
  onLogin: () => void;
}

const LoginScreen: React.FC<Props> = ({ onLogin }) => {
  const [passcode, setPasscode] = useState('');
  const [showContent, setShowContent] = useState(false);
  const [error, setError] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  // The secret lock code
  const LOCK_CODE = '19781978'; 

  useEffect(() => {
    // Entrance animation
    setTimeout(() => setShowContent(true), 100);
  }, []);

  // Handle Keypad Press
  const handlePress = (num: string) => {
    if (passcode.length < 8 && !isLoading) {
      setPasscode(prev => prev + num);
      setError('');
    }
  };

  const handleDelete = () => {
    if (!isLoading) {
      setPasscode(prev => prev.slice(0, -1));
      setError('');
    }
  };

  // Auto-check when code length is reached
  useEffect(() => {
    if (passcode.length === 8) {
      setIsLoading(true);
      setTimeout(() => {
        if (passcode === LOCK_CODE) {
          onLogin();
        } else {
          setError('ভুল পিন! আবার চেষ্টা করুন');
          setPasscode('');
          setIsLoading(false);
        }
      }, 800); // Small delay for effect
    }
  }, [passcode, onLogin]);

  return (
    <div className="min-h-screen bg-slate-900 flex flex-col items-center justify-center relative overflow-hidden font-sans select-none">
      
      {/* Background Animated Elements */}
      <div className="absolute top-0 left-0 w-full h-full overflow-hidden z-0 opacity-20 pointer-events-none">
         <div className="absolute top-10 left-10 w-40 h-40 bg-blue-600 rounded-full mix-blend-screen filter blur-3xl animate-pulse"></div>
         <div className="absolute bottom-10 right-10 w-40 h-40 bg-purple-600 rounded-full mix-blend-screen filter blur-3xl animate-pulse" style={{ animationDelay: '1.5s' }}></div>
      </div>

      <div className={`z-10 w-full max-w-sm flex flex-col items-center transition-all duration-1000 transform ${showContent ? 'translate-y-0 opacity-100' : 'translate-y-10 opacity-0'}`}>
        
        {/* Branding */}
        <div className="flex flex-col items-center mb-8">
          <div className="bg-gradient-to-br from-blue-500 to-purple-600 p-5 rounded-2xl shadow-lg shadow-blue-500/20 mb-4 animate-bounce">
            <ShieldCheck size={48} className="text-white" />
          </div>
          <h1 className="text-3xl font-bold text-white tracking-wider">Master Admin</h1>
          <div className="flex items-center gap-2 mt-2 text-blue-300 text-xs uppercase tracking-widest">
             <Lock size={12} />
             <span>Security Lock Active</span>
          </div>
        </div>

        {/* Pin Display */}
        <div className="mb-8 w-full flex justify-center gap-3">
          {[...Array(8)].map((_, i) => (
            <div 
              key={i} 
              className={`w-3 h-3 md:w-4 md:h-4 rounded-full transition-all duration-300 ${
                i < passcode.length 
                  ? 'bg-blue-500 scale-110 shadow-[0_0_10px_rgba(59,130,246,0.8)]' 
                  : 'bg-slate-700 border border-slate-600'
              } ${error ? 'bg-red-500 animate-pulse' : ''}`}
            />
          ))}
        </div>

        {error && (
          <div className="text-red-400 text-sm mb-4 font-medium animate-pulse">
            {error}
          </div>
        )}

        {isLoading && (
           <div className="text-blue-400 text-sm mb-4 font-medium flex items-center gap-2">
             <Activity className="animate-spin" size={16} /> Verifying...
           </div>
        )}

        {/* Keypad */}
        <div className="grid grid-cols-3 gap-6 w-full max-w-[280px]">
          {[1, 2, 3, 4, 5, 6, 7, 8, 9].map((num) => (
            <button
              key={num}
              onClick={() => handlePress(num.toString())}
              disabled={isLoading}
              className="w-16 h-16 rounded-full bg-slate-800/50 hover:bg-slate-700 text-white text-2xl font-bold border border-slate-700 shadow-lg active:scale-95 transition-all flex items-center justify-center backdrop-blur-sm"
            >
              {num}
            </button>
          ))}
          
          <div className="flex items-center justify-center">
            {/* Empty space for alignment */}
          </div>

          <button
            onClick={() => handlePress('0')}
            disabled={isLoading}
            className="w-16 h-16 rounded-full bg-slate-800/50 hover:bg-slate-700 text-white text-2xl font-bold border border-slate-700 shadow-lg active:scale-95 transition-all flex items-center justify-center backdrop-blur-sm"
          >
            0
          </button>

          <button
            onClick={handleDelete}
            disabled={isLoading}
            className="w-16 h-16 rounded-full bg-red-500/10 hover:bg-red-500/20 text-red-400 text-xl font-bold border border-red-500/30 shadow-lg active:scale-95 transition-all flex items-center justify-center backdrop-blur-sm"
          >
            <Delete size={24} />
          </button>
        </div>

        <div className="mt-8 text-center opacity-50">
           {/* Pin hint removed for security */}
        </div>

      </div>
    </div>
  );
};

export default LoginScreen;