import React, { useState } from 'react';
import { Settings, DepositMethod } from '../types';
import { Save, Plus, Trash2, Check, X, ToggleLeft, ToggleRight, User, Users, Eye } from 'lucide-react';
import { updateSettings, addDepositMethod, deleteDepositMethod, updateDepositMethod } from '../services/firebaseService';

interface Props {
  settings: Settings;
  setSettings: React.Dispatch<React.SetStateAction<Settings>>;
  depositMethods: DepositMethod[];
  setDepositMethods: React.Dispatch<React.SetStateAction<DepositMethod[]>>;
}

const SettingsPanel: React.FC<Props> = ({ settings, setSettings, depositMethods }) => {
  const [newMethod, setNewMethod] = useState<Partial<DepositMethod>>({
    name: '', type: 'Personal', instruction: 'Send Money', minAmount: 0, maxAmount: 0, number: '', requirements: [], audience: 'All'
  });
  
  // Separate lists
  const pendingMethods = depositMethods.filter(d => d.status === 'pending');
  const activeMethods = depositMethods.filter(d => d.status === 'active' || d.status === 'inactive');

  const handleSaveSettings = async () => {
    try {
      await updateSettings(settings);
      alert('Settings Saved to Database!');
    } catch (e) {
      alert('Error saving settings');
    }
  };

  const handleAddMethod = async () => {
    if (!newMethod.name || !newMethod.number) return;
    try {
      await addDepositMethod({
        name: newMethod.name!,
        type: newMethod.type as any,
        number: newMethod.number!,
        minAmount: Number(newMethod.minAmount),
        maxAmount: Number(newMethod.maxAmount),
        instruction: newMethod.instruction || '',
        requirements: newMethod.requirements || [],
        status: 'active', // Admin added methods are active by default
        addedBy: 'admin',
        audience: newMethod.audience as any || 'All'
      });
      setNewMethod({ name: '', type: 'Personal', instruction: 'Send Money', minAmount: 0, maxAmount: 0, number: '', requirements: [], audience: 'All' });
      alert("Method Added");
    } catch (e) {
      console.error(e);
    }
  };

  const handleDeleteMethod = async (id: string) => {
    if(confirm("Are you sure?")) {
      await deleteDepositMethod(id);
    }
  };

  const handleUpdateStatus = async (id: string, status: 'active' | 'inactive' | 'rejected') => {
    await updateDepositMethod(id, { status });
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
      
      {/* General Settings */}
      <div className="bg-white p-6 rounded-lg shadow">
        <h3 className="text-lg font-bold text-gray-800 mb-4 border-b pb-2">সাধারণ সেটিংস</h3>
        
        <div className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-700">ডলার রেট (BDT)</label>
            <input 
              type="number" 
              value={settings.dollarRate} 
              onChange={e => setSettings({...settings, dollarRate: parseFloat(e.target.value)})}
              className="mt-1 block w-full border border-gray-300 rounded-md shadow-sm p-2"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700">মিনিমাম উইথড্র লিমিট ($)</label>
            <input 
              type="number" 
              value={settings.minWithdraw} 
              onChange={e => setSettings({...settings, minWithdraw: parseFloat(e.target.value)})}
              className="mt-1 block w-full border border-gray-300 rounded-md shadow-sm p-2"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700">টেলিগ্রাম লিংক</label>
            <input 
              type="text" 
              value={settings.telegramLink} 
              onChange={e => setSettings({...settings, telegramLink: e.target.value})}
              className="mt-1 block w-full border border-gray-300 rounded-md shadow-sm p-2"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700">হোয়াটসঅ্যাপ লিংক</label>
            <input 
              type="text" 
              value={settings.whatsappLink} 
              onChange={e => setSettings({...settings, whatsappLink: e.target.value})}
              className="mt-1 block w-full border border-gray-300 rounded-md shadow-sm p-2"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700">নোটিশ টেক্সট</label>
            <textarea 
              value={settings.noticeText} 
              onChange={e => setSettings({...settings, noticeText: e.target.value})}
              className="mt-1 block w-full border border-gray-300 rounded-md shadow-sm p-2 h-24"
            />
          </div>
          <button onClick={handleSaveSettings} className="w-full bg-blue-600 text-white py-2 rounded hover:bg-blue-700 flex justify-center items-center gap-2">
            <Save size={18} /> সেভ করুন
          </button>
        </div>
      </div>

      {/* Deposit Methods Section */}
      <div className="space-y-6">
        
        {/* Pending Requests */}
        {pendingMethods.length > 0 && (
          <div className="bg-yellow-50 border border-yellow-200 p-6 rounded-lg shadow">
            <h3 className="text-lg font-bold text-yellow-800 mb-4 flex items-center gap-2">
              <span className="relative flex h-3 w-3">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-yellow-400 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-3 w-3 bg-yellow-500"></span>
              </span>
              ডিপোজিট নাম্বার রিকোয়েস্ট ({pendingMethods.length})
            </h3>
            <div className="space-y-3">
              {pendingMethods.map(method => (
                <div key={method.id} className="bg-white p-4 rounded shadow-sm border border-yellow-100">
                  <div className="flex justify-between items-start mb-2">
                    <div>
                      <p className="font-bold text-gray-800 text-lg">{method.name}</p>
                      <p className="text-sm font-mono text-gray-600 bg-gray-100 px-2 py-0.5 rounded inline-block">{method.number}</p>
                    </div>
                    {method.agentName && (
                      <span className="flex items-center gap-1 text-xs font-semibold bg-purple-100 text-purple-700 px-2 py-1 rounded-full">
                         <User size={12}/> {method.agentName}
                      </span>
                    )}
                  </div>
                  <div className="flex justify-between items-center text-xs text-gray-500 mb-3">
                    <span>Type: {method.type}</span>
                    <span>Limit: {method.minAmount}-{method.maxAmount}</span>
                  </div>
                  <div className="flex gap-2">
                    <button 
                      onClick={() => handleUpdateStatus(method.id, 'rejected')}
                      className="flex-1 bg-red-100 hover:bg-red-200 text-red-700 py-2 rounded flex justify-center items-center gap-1 text-sm font-medium transition"
                    >
                      <X size={16}/> Reject
                    </button>
                    <button 
                      onClick={() => handleUpdateStatus(method.id, 'active')}
                      className="flex-1 bg-green-600 hover:bg-green-700 text-white py-2 rounded flex justify-center items-center gap-1 text-sm font-medium transition shadow"
                    >
                      <Check size={16}/> Approve
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Manage Deposit Methods */}
        <div className="bg-white p-6 rounded-lg shadow">
          <h3 className="text-lg font-bold text-gray-800 mb-4 border-b pb-2">ডিপোজিট মেথড ম্যানেজমেন্ট</h3>
          
          <div className="bg-gray-50 p-4 rounded mb-6 border">
            <h4 className="font-semibold text-sm mb-2 text-gray-700">নতুন মেথড এড করুন (Admin)</h4>
            <div className="grid grid-cols-2 gap-3 mb-3">
              <input placeholder="নাম (যেমন: Bkash)" className="border p-2 rounded text-sm" value={newMethod.name} onChange={e => setNewMethod({...newMethod, name: e.target.value})} />
              <select className="border p-2 rounded text-sm" value={newMethod.type} onChange={e => setNewMethod({...newMethod, type: e.target.value as any})}>
                <option value="Personal">Personal</option>
                <option value="Agent">Agent</option>
                <option value="Merchant">Merchant</option>
              </select>
              
              <input placeholder="নাম্বার" className="border p-2 rounded text-sm col-span-2" value={newMethod.number} onChange={e => setNewMethod({...newMethod, number: e.target.value})} />
              
              <input placeholder="Min Amount" type="number" className="border p-2 rounded text-sm" value={newMethod.minAmount} onChange={e => setNewMethod({...newMethod, minAmount: parseFloat(e.target.value)})} />
              <input placeholder="Max Amount" type="number" className="border p-2 rounded text-sm" value={newMethod.maxAmount} onChange={e => setNewMethod({...newMethod, maxAmount: parseFloat(e.target.value)})} />
              
              <div className="col-span-2 grid grid-cols-2 gap-3">
                 <select className="border p-2 rounded text-sm" value={newMethod.instruction} onChange={e => setNewMethod({...newMethod, instruction: e.target.value})}>
                    <option value="Send Money">Send Money</option>
                    <option value="Cash Out">Cash Out</option>
                    <option value="Payment">Payment</option>
                  </select>
                  <select className="border p-2 rounded text-sm font-medium text-blue-700 bg-blue-50" value={newMethod.audience} onChange={e => setNewMethod({...newMethod, audience: e.target.value as any})}>
                    <option value="All">Everyone (All)</option>
                    <option value="Agents Only">Agents Only</option>
                    <option value="Users Only">Users Only</option>
                  </select>
              </div>

              <div className="col-span-2">
                 <input 
                  placeholder="Requirements (comma separated: TrxID, Last 4 Digit)" 
                  className="border p-2 rounded text-sm w-full"
                  onChange={e => setNewMethod({...newMethod, requirements: e.target.value.split(',').map(s => s.trim())})}
                 />
              </div>
            </div>
            <button onClick={handleAddMethod} className="w-full bg-blue-600 text-white py-2 rounded text-sm flex justify-center items-center gap-1 font-medium hover:bg-blue-700">
              <Plus size={16} /> এড করুন
            </button>
          </div>

          <div className="space-y-3">
            <h4 className="font-semibold text-sm text-gray-600 mb-2">Active/Inactive List</h4>
            {activeMethods.length === 0 ? (
              <p className="text-center text-gray-400 text-sm py-4">No methods available</p>
            ) : (
              activeMethods.map(method => (
                <div key={method.id} className={`border p-3 rounded flex flex-col sm:flex-row justify-between items-center gap-3 ${method.status === 'inactive' ? 'bg-gray-100 opacity-75' : 'bg-white border-blue-100 shadow-sm'}`}>
                  <div className="flex-1 w-full">
                    <div className="flex items-center gap-2 flex-wrap">
                      <p className="font-bold text-gray-800">{method.name}</p>
                      <span className={`text-[10px] px-1.5 py-0.5 rounded border ${
                        method.type === 'Personal' ? 'bg-blue-50 text-blue-600 border-blue-200' : 
                        method.type === 'Agent' ? 'bg-purple-50 text-purple-600 border-purple-200' : 'bg-orange-50 text-orange-600 border-orange-200'
                      }`}>
                        {method.type}
                      </span>
                      {method.status === 'inactive' && <span className="text-[10px] bg-red-100 text-red-600 px-1 rounded">Inactive</span>}
                      {method.audience !== 'All' && (
                        <span className="text-[10px] flex items-center gap-0.5 bg-gray-600 text-white px-1.5 py-0.5 rounded">
                          <Eye size={10} /> {method.audience}
                        </span>
                      )}
                    </div>
                    <p className="text-sm font-mono text-gray-600 mt-1">{method.number}</p>
                    {method.agentName && <p className="text-xs text-gray-400 mt-1">Requested by: {method.agentName}</p>}
                  </div>
                  
                  <div className="flex items-center gap-3 w-full sm:w-auto justify-end">
                    <button 
                      onClick={() => handleUpdateStatus(method.id, method.status === 'active' ? 'inactive' : 'active')}
                      className={`p-2 rounded-full transition-colors ${method.status === 'active' ? 'text-green-600 hover:bg-green-50' : 'text-gray-400 hover:bg-gray-200'}`}
                      title={method.status === 'active' ? "Deactivate" : "Activate"}
                    >
                      {method.status === 'active' ? <ToggleRight size={28} /> : <ToggleLeft size={28} />}
                    </button>
                    
                    <button 
                      onClick={() => handleDeleteMethod(method.id)} 
                      className="text-red-400 hover:text-red-600 hover:bg-red-50 p-2 rounded-full transition"
                      title="Delete Permanently"
                    >
                      <Trash2 size={18} />
                    </button>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default SettingsPanel;