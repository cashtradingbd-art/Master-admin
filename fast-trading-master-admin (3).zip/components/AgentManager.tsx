import React, { useState } from 'react';
import { Agent } from '../types';
import { Plus, Trash2, Edit, CheckCircle, XCircle, DollarSign, Save, X } from 'lucide-react';
import { addAgent, updateAgent } from '../services/firebaseService';

interface Props {
  agents: Agent[];
  setAgents: React.Dispatch<React.SetStateAction<Agent[]>>; // Keep for compatibility but we mostly rely on live updates
}

const AgentManager: React.FC<Props> = ({ agents }) => {
  const [showForm, setShowForm] = useState(false);
  const [newAgent, setNewAgent] = useState({ name: '', phone: '', password: '', commission: 0 });
  
  const [balanceModal, setBalanceModal] = useState<{ agentId: string, type: 'add' | 'deduct' } | null>(null);
  const [amount, setAmount] = useState('');
  
  const [editCommissionId, setEditCommissionId] = useState<string | null>(null);
  const [tempCommission, setTempCommission] = useState<string>('');

  const handleCreateAgent = async () => {
    if (!newAgent.name || !newAgent.phone || !newAgent.password) return;
    try {
      await addAgent({
        name: newAgent.name,
        phone: newAgent.phone,
        password: newAgent.password,
        commissionRate: newAgent.commission,
        balance: 0,
        isActive: true,
        totalEarned: 0,
      });
      setNewAgent({ name: '', phone: '', password: '', commission: 0 });
      setShowForm(false);
      alert("এজেন্ট তৈরি হয়েছে!");
    } catch (e) {
      console.error(e);
      alert("এরর হয়েছে!");
    }
  };

  const toggleStatus = async (id: string, currentStatus: boolean) => {
    await updateAgent(id, { isActive: !currentStatus });
  };

  const handleBalanceUpdate = async () => {
    if (!balanceModal || !amount) return;
    const val = parseFloat(amount);
    if (isNaN(val)) return;

    const agent = agents.find(a => a.id === balanceModal.agentId);
    if (!agent) return;

    const newBalance = balanceModal.type === 'add' ? agent.balance + val : agent.balance - val;
    await updateAgent(agent.id, { balance: newBalance });
    
    setBalanceModal(null);
    setAmount('');
  };

  const startEditCommission = (agent: Agent) => {
    setEditCommissionId(agent.id);
    setTempCommission(agent.commissionRate.toString());
  };

  const saveCommission = async (id: string) => {
    const val = parseFloat(tempCommission);
    if (!isNaN(val)) {
      await updateAgent(id, { commissionRate: val });
    }
    setEditCommissionId(null);
  };

  return (
    <div className="bg-white rounded-lg shadow p-6">
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-xl font-bold text-gray-800">সাব-এজেন্ট ম্যানেজমেন্ট</h2>
        <button 
          onClick={() => setShowForm(!showForm)}
          className="bg-purple-600 hover:bg-purple-700 text-white px-4 py-2 rounded-lg flex items-center gap-2"
        >
          <Plus size={18} /> নতুন এজেন্ট
        </button>
      </div>

      {showForm && (
        <div className="bg-gray-50 p-4 rounded-lg mb-6 border border-gray-200">
          <h3 className="font-semibold mb-3">নতুন এজেন্ট তৈরি করুন</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <input 
              type="text" placeholder="নাম" 
              className="border p-2 rounded" 
              value={newAgent.name} onChange={e => setNewAgent({...newAgent, name: e.target.value})}
            />
            <input 
              type="text" placeholder="ফোন নাম্বার" 
              className="border p-2 rounded" 
              value={newAgent.phone} onChange={e => setNewAgent({...newAgent, phone: e.target.value})}
            />
            <input 
              type="text" placeholder="পাসওয়ার্ড" 
              className="border p-2 rounded" 
              value={newAgent.password} onChange={e => setNewAgent({...newAgent, password: e.target.value})}
            />
            <input 
              type="number" placeholder="কমিশন (প্রতি হাজারে কত?)" 
              className="border p-2 rounded" 
              value={newAgent.commission} onChange={e => setNewAgent({...newAgent, commission: parseFloat(e.target.value)})}
            />
          </div>
          <button onClick={handleCreateAgent} className="mt-4 bg-green-600 text-white px-4 py-2 rounded">সেভ করুন</button>
        </div>
      )}

      {/* Balance Modal */}
      {balanceModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white p-6 rounded-lg w-80">
            <h3 className="text-lg font-bold mb-4">
              {balanceModal.type === 'add' ? 'ব্যালেন্স এড করুন' : 'ব্যালেন্স কেটে নিন'}
            </h3>
            <input 
              type="number" 
              placeholder="পরিমাণ" 
              className="border w-full p-2 rounded mb-4"
              value={amount}
              onChange={e => setAmount(e.target.value)}
            />
            <div className="flex justify-end gap-2">
              <button onClick={() => setBalanceModal(null)} className="px-3 py-1 bg-gray-300 rounded">বন্ধ</button>
              <button onClick={handleBalanceUpdate} className="px-3 py-1 bg-blue-600 text-white rounded">নিশ্চিত</button>
            </div>
          </div>
        </div>
      )}

      <div className="overflow-x-auto">
        <table className="w-full text-left border-collapse">
          <thead>
            <tr className="bg-gray-100 text-gray-700">
              <th className="p-3">নাম</th>
              <th className="p-3">ফোন</th>
              <th className="p-3">পাসওয়ার্ড</th>
              <th className="p-3">ব্যালেন্স ($)</th>
              <th className="p-3">কমিশন (প্রতি হাজারে)</th>
              <th className="p-3">স্ট্যাটাস</th>
              <th className="p-3 text-center">অ্যাকশন</th>
            </tr>
          </thead>
          <tbody>
            {agents.map(agent => (
              <tr key={agent.id} className="border-b hover:bg-gray-50">
                <td className="p-3 font-medium">{agent.name}</td>
                <td className="p-3">{agent.phone}</td>
                <td className="p-3 font-mono text-sm text-red-500">{agent.password}</td>
                <td className="p-3 font-bold text-green-600">${agent.balance.toFixed(2)}</td>
                <td className="p-3">
                  {editCommissionId === agent.id ? (
                    <div className="flex items-center gap-1">
                      <input 
                        type="number" 
                        className="w-20 border rounded p-1 text-sm" 
                        value={tempCommission}
                        onChange={e => setTempCommission(e.target.value)}
                        autoFocus
                        placeholder="Ex: 25"
                      />
                      <button onClick={() => saveCommission(agent.id)} className="text-green-600"><CheckCircle size={16}/></button>
                      <button onClick={() => setEditCommissionId(null)} className="text-red-500"><X size={16}/></button>
                    </div>
                  ) : (
                    <div className="flex items-center gap-2 group">
                      <span className="bg-purple-100 text-purple-700 px-2 py-0.5 rounded text-sm font-bold">
                        {agent.commissionRate}
                      </span>
                      <button 
                        onClick={() => startEditCommission(agent)} 
                        className="opacity-0 group-hover:opacity-100 text-gray-400 hover:text-blue-600 transition"
                      >
                        <Edit size={14} />
                      </button>
                    </div>
                  )}
                </td>
                <td className="p-3">
                  <button 
                    onClick={() => toggleStatus(agent.id, agent.isActive)}
                    className={`flex items-center gap-1 px-2 py-1 rounded text-xs font-bold ${agent.isActive ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700'}`}
                  >
                    {agent.isActive ? <CheckCircle size={14}/> : <XCircle size={14}/>}
                    {agent.isActive ? 'Active' : 'Inactive'}
                  </button>
                </td>
                <td className="p-3">
                  <div className="flex justify-center gap-2">
                    <button 
                      onClick={() => setBalanceModal({ agentId: agent.id, type: 'add' })}
                      className="bg-blue-100 text-blue-600 p-2 rounded hover:bg-blue-200" title="ব্যালেন্স দিন"
                    >
                      <Plus size={16} />
                    </button>
                    <button 
                      onClick={() => setBalanceModal({ agentId: agent.id, type: 'deduct' })}
                      className="bg-yellow-100 text-yellow-600 p-2 rounded hover:bg-yellow-200" title="ব্যালেন্স কাটুন"
                    >
                      <Trash2 size={16} />
                    </button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default AgentManager;