import React from 'react';
import { Transaction, Agent } from '../types';
import { Check, X, UserCog, Wallet, ArrowRight } from 'lucide-react';

interface Props {
  transactions: Transaction[];
  agents: Agent[];
  onApprove: (id: string) => void;
  onReject: (id: string) => void;
}

const DepositMonitor: React.FC<Props> = ({ transactions, agents, onApprove, onReject }) => {
  // Filtering only pending deposits that are assigned to an agent
  const pendingDeposits = transactions.filter(t => t.type === 'deposit' && t.status === 'pending');
  const recentDeposits = transactions.filter(t => t.type === 'deposit' && t.status !== 'pending').slice(0, 5);

  const getAgent = (agentId?: string) => agents.find(a => a.id === agentId);
  const getAgentName = (agentId?: string) => {
    const agent = getAgent(agentId);
    return agent ? agent.name : 'System/Admin';
  };

  return (
    <div className="bg-white rounded-lg shadow p-6 mb-8 border border-purple-100">
      <div className="flex items-center justify-between mb-4">
        <h2 className="text-xl font-bold text-purple-800 flex items-center gap-2">
           <UserCog size={24}/> সাব-এজেন্ট ডিপোজিট রিকোয়েস্ট
        </h2>
        <span className="text-xs text-gray-500 bg-gray-100 px-2 py-1 rounded">এডমিন ভিউ</span>
      </div>
      
      <p className="text-sm text-gray-600 mb-6 bg-purple-50 p-3 rounded border border-purple-100">
        <strong>সিস্টেম ফ্লো:</strong> এখানে সাব-এজেন্টের কাছে আসা রিকোয়েস্টগুলো দেখা যাচ্ছে। <br/>
        এপ্রুভ করলে: <span className="text-red-600">এজেন্ট ব্যালেন্স থেকে এমাউন্ট কাটবে</span> → <span className="text-blue-600">ইউজার ব্যালেন্স এড হবে</span> → <span className="text-green-600">এজেন্ট কমিশন পাবে</span>।
      </p>

      {/* Pending List */}
      <h3 className="font-bold text-gray-700 mb-3 border-b pb-1">Pending Requests (Agent Panel View)</h3>
      {pendingDeposits.length === 0 ? (
        <p className="text-gray-400 italic mb-6">কোন পেন্ডিং রিকোয়েস্ট নেই</p>
      ) : (
        <div className="grid gap-3 mb-6">
          {pendingDeposits.map(trx => {
            const agent = getAgent(trx.agentId);
            const canApprove = agent && agent.balance >= trx.amount;
            
            // Calculate potential commission for display
            const potentialCommission = agent ? (trx.amount / 1000) * agent.commissionRate : 0;

            return (
              <div key={trx.id} className="border border-gray-200 bg-white rounded-lg p-4 shadow-sm">
                
                <div className="flex flex-col md:flex-row justify-between md:items-center gap-4">
                  {/* Left Side: Request Info */}
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-1">
                      <span className="bg-purple-600 text-white px-3 py-1 rounded font-bold text-lg">${trx.amount}</span>
                      <ArrowRight className="text-gray-400" size={16} />
                      <span className="text-gray-700 font-medium">{trx.userEmail}</span>
                    </div>
                    <div className="text-xs text-gray-500 flex gap-3">
                       <span>Method: {trx.method}</span>
                       <span>TrxID: {trx.details}</span>
                    </div>
                  </div>

                  {/* Middle: Agent Status Calculation */}
                  <div className="flex-1 bg-gray-50 p-2 rounded text-xs border">
                    {agent ? (
                      <div>
                        <p className="font-bold text-gray-700 mb-1">এজেন্ট: {agent.name}</p>
                        <div className="grid grid-cols-2 gap-x-4 gap-y-1">
                           <span className="text-gray-500">বর্তমান ব্যালেন্স:</span>
                           <span className={`font-mono font-bold ${canApprove ? 'text-green-600' : 'text-red-600'}`}>
                             ${agent.balance.toFixed(2)}
                           </span>

                           <span className="text-gray-500">কেটে নেওয়া হবে:</span>
                           <span className="text-red-500 font-mono">-${trx.amount}</span>

                           <span className="text-gray-500">কমিশন পাবে:</span>
                           <span className="text-green-600 font-mono">+${potentialCommission.toFixed(2)}</span>
                        </div>
                        {!canApprove && (
                          <div className="mt-2 text-red-600 font-bold bg-red-50 px-2 py-1 rounded text-center">
                             অপর্যাপ্ত ব্যালেন্স (Insufficient)
                          </div>
                        )}
                      </div>
                    ) : (
                      <p className="text-red-500">কোন এজেন্ট অ্যাসাইন করা নেই</p>
                    )}
                  </div>

                  {/* Right: Actions */}
                  <div className="flex gap-2 items-center">
                     <button 
                        onClick={() => onReject(trx.id)}
                        className="bg-red-100 hover:bg-red-200 text-red-700 p-2 rounded transition flex flex-col items-center justify-center w-20"
                        title="Reject Request"
                      >
                        <X size={20} />
                        <span className="text-xs font-bold">Reject</span>
                      </button>

                      <button 
                        onClick={() => onApprove(trx.id)}
                        className={`p-2 rounded transition flex flex-col items-center justify-center w-24 text-white shadow ${
                          agent && !canApprove 
                          ? 'bg-gray-400 cursor-not-allowed' 
                          : 'bg-green-600 hover:bg-green-700'
                        }`}
                        disabled={!!(agent && !canApprove)}
                        title={canApprove ? "Approve & Send" : "Insufficient Balance"}
                      >
                        <Check size={20} />
                        <span className="text-xs font-bold">Approve</span>
                      </button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Recent History */}
      <h3 className="font-bold text-gray-700 mb-3 border-b pb-1">Recent Logs</h3>
      <div className="overflow-x-auto">
        <table className="w-full text-left text-sm">
          <thead>
            <tr className="text-gray-500 bg-gray-50">
              <th className="p-2">Date</th>
              <th className="p-2">User</th>
              <th className="p-2">Amount</th>
              <th className="p-2">Agent</th>
              <th className="p-2">Status</th>
            </tr>
          </thead>
          <tbody>
            {recentDeposits.map(trx => (
               <tr key={trx.id} className="border-b hover:bg-gray-50">
                 <td className="p-2 text-gray-500">{trx.date}</td>
                 <td className="p-2">{trx.userEmail}</td>
                 <td className="p-2 font-bold">${trx.amount}</td>
                 <td className="p-2 text-purple-600 font-medium">{getAgentName(trx.agentId)}</td>
                 <td className="p-2">
                   <span className={`px-2 py-0.5 rounded text-xs font-bold ${
                     trx.status === 'approved' ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700'
                   }`}>
                     {trx.status.toUpperCase()}
                   </span>
                 </td>
               </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default DepositMonitor;