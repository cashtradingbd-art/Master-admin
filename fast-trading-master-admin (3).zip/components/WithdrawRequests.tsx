import React from 'react';
import { Transaction, User } from '../types';
import { Check, X, Wallet } from 'lucide-react';

interface Props {
  transactions: Transaction[];
  users: User[];
  onAction: (id: string, action: 'approve' | 'reject') => void;
}

const WithdrawRequests: React.FC<Props> = ({ transactions, users, onAction }) => {
  const pending = transactions.filter(t => t.type === 'withdraw' && t.status === 'pending');

  return (
    <div className="bg-white rounded-lg shadow p-6">
      <h2 className="text-xl font-bold text-gray-800 mb-4">উইথড্র রিকোয়েস্ট (Pending)</h2>
      
      {pending.length === 0 ? (
        <p className="text-gray-500 italic text-center py-8">কোন পেন্ডিং রিকোয়েস্ট নেই</p>
      ) : (
        <div className="grid gap-4">
          {pending.map(trx => {
            const user = users.find(u => u.id === trx.userId || u.email === trx.userEmail);
            const currentBalance = user ? user.balance : 0;
            const hasEnoughBalance = currentBalance >= trx.amount;

            return (
              <div key={trx.id} className="border rounded-lg p-4 flex flex-col md:flex-row justify-between items-center bg-gray-50 hover:bg-white hover:shadow-md transition">
                <div className="mb-4 md:mb-0">
                  <div className="flex items-center gap-2 mb-1">
                    <span className="font-bold text-lg text-gray-800">${trx.amount}</span>
                    <span className="text-sm bg-blue-100 text-blue-700 px-2 py-0.5 rounded">{trx.method}</span>
                  </div>
                  <p className="text-sm text-gray-600">User: <span className="font-medium">{trx.userEmail}</span></p>
                  <div className="text-xs text-gray-500 mt-1">
                    Number: {trx.details} | Date: {trx.date}
                  </div>
                  
                  {/* Show Current Balance */}
                  <div className="mt-2 flex items-center gap-2 text-sm bg-white border px-2 py-1 rounded w-fit">
                    <Wallet size={14} className="text-gray-400" />
                    <span className="text-gray-500">বর্তমান ব্যালেন্স:</span>
                    <span className={`font-bold ${hasEnoughBalance ? 'text-green-600' : 'text-red-600'}`}>
                      ${currentBalance.toFixed(2)}
                    </span>
                    {!hasEnoughBalance && <span className="text-xs text-red-500">(অপর্যাপ্ত)</span>}
                  </div>
                </div>
                
                <div className="flex gap-3">
                  <button 
                    onClick={() => onAction(trx.id, 'reject')}
                    className="flex items-center gap-1 bg-red-100 hover:bg-red-200 text-red-700 px-4 py-2 rounded-lg font-medium transition"
                  >
                    <X size={18} /> বাতিল
                  </button>
                  <button 
                    onClick={() => onAction(trx.id, 'approve')}
                    disabled={!hasEnoughBalance}
                    className={`flex items-center gap-1 px-6 py-2 rounded-lg font-medium shadow transition text-white ${
                      hasEnoughBalance ? 'bg-green-600 hover:bg-green-700' : 'bg-gray-400 cursor-not-allowed'
                    }`}
                  >
                    <Check size={18} /> এপ্রুভ করুন
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};

export default WithdrawRequests;