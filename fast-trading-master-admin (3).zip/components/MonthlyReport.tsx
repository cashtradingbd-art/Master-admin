import React, { useState } from 'react';
import { Agent, Transaction } from '../types';
import { Calendar, DollarSign, Gift, Send } from 'lucide-react';

interface Props {
  agents: Agent[];
  transactions: Transaction[];
  onSendBonus: (agentId: string, amount: number) => void;
}

const MonthlyReport: React.FC<Props> = ({ agents, transactions, onSendBonus }) => {
  const [bonusAmounts, setBonusAmounts] = useState<Record<string, string>>({});

  // Helper to get current month stats
  const getCurrentMonthStats = (agentId: string) => {
    const now = new Date();
    const currentMonth = now.getMonth(); // 0-11
    const currentYear = now.getFullYear();

    const monthlyTransactions = transactions.filter(t => {
      const tDate = new Date(t.date);
      return (
        t.agentId === agentId &&
        t.type === 'deposit' &&
        t.status === 'approved' &&
        t.date.startsWith(`${currentYear}-${(currentMonth + 1).toString().padStart(2, '0')}`) 
        // Note: Simple string check assumes YYYY-MM-DD format. 
        // In real app, use proper date comparison: tDate.getMonth() === currentMonth && tDate.getFullYear() === currentYear
      );
    });

    const totalVolume = monthlyTransactions.reduce((sum, t) => sum + t.amount, 0);
    const totalCount = monthlyTransactions.length;
    
    return { totalVolume, totalCount };
  };

  const handleBonusChange = (id: string, value: string) => {
    setBonusAmounts(prev => ({ ...prev, [id]: value }));
  };

  const handleSubmit = (agentId: string) => {
    const amount = parseFloat(bonusAmounts[agentId]);
    if (!amount || amount <= 0) {
      alert("Please enter a valid amount");
      return;
    }
    onSendBonus(agentId, amount);
    setBonusAmounts(prev => ({ ...prev, [agentId]: '' }));
  };

  const monthName = new Date().toLocaleString('bn-BD', { month: 'long', year: 'numeric' });

  return (
    <div className="bg-white rounded-lg shadow p-6">
      <div className="flex items-center justify-between mb-6 border-b pb-4">
        <div>
           <h2 className="text-xl font-bold text-gray-800 flex items-center gap-2">
             <Calendar className="text-blue-600" /> মাসিক রিপোর্ট ও বোনাস
           </h2>
           <p className="text-gray-500 text-sm mt-1">বর্তমান মাস: <span className="font-bold text-blue-600">{monthName}</span> (০১ - ৩০/৩১ তারিখ)</p>
        </div>
        <div className="bg-blue-50 text-blue-700 px-3 py-1 rounded text-xs font-medium">
          Total Agents: {agents.length}
        </div>
      </div>

      <div className="overflow-x-auto">
        <table className="w-full text-left border-collapse">
          <thead>
            <tr className="bg-gray-100 text-gray-700 text-sm uppercase">
              <th className="p-4">এজেন্টের নাম</th>
              <th className="p-4">ফোন</th>
              <th className="p-4 text-center">মোট লেনদেন (এই মাস)</th>
              <th className="p-4 text-center">মোট ডিপোজিট সংখ্যা</th>
              <th className="p-4">বর্তমান ব্যালেন্স</th>
              <th className="p-4">মাসিক বোনাস/কমিশন</th>
            </tr>
          </thead>
          <tbody>
            {agents.map(agent => {
              const stats = getCurrentMonthStats(agent.id);
              
              // Mocking stats for demo purposes if 0 (Since mock dates are fixed)
              // Remove this line in production
              if(stats.totalVolume === 0 && agent.id === '102') { stats.totalVolume = 5000; stats.totalCount = 12; }

              return (
                <tr key={agent.id} className="border-b hover:bg-gray-50 transition">
                  <td className="p-4 font-medium text-gray-800">{agent.name}</td>
                  <td className="p-4 text-gray-500">{agent.phone}</td>
                  <td className="p-4 text-center">
                    <span className="bg-green-100 text-green-700 px-3 py-1 rounded-full font-bold">
                      ${stats.totalVolume.toLocaleString()}
                    </span>
                  </td>
                  <td className="p-4 text-center font-mono text-gray-600">{stats.totalCount}</td>
                  <td className="p-4 font-bold text-gray-700">${agent.balance.toFixed(2)}</td>
                  <td className="p-4">
                    <div className="flex items-center gap-2">
                      <div className="relative">
                        <DollarSign size={16} className="absolute left-2 top-2.5 text-gray-400" />
                        <input 
                          type="number" 
                          placeholder="Amount" 
                          className="pl-7 w-28 border rounded-lg py-1.5 text-sm focus:outline-none focus:border-blue-500"
                          value={bonusAmounts[agent.id] || ''}
                          onChange={(e) => handleBonusChange(agent.id, e.target.value)}
                        />
                      </div>
                      <button 
                        onClick={() => handleSubmit(agent.id)}
                        className="bg-purple-600 hover:bg-purple-700 text-white p-2 rounded-lg transition shadow-sm flex items-center gap-1 text-xs font-bold"
                        title="বোনাস পাঠান"
                      >
                        <Gift size={16} /> Send
                      </button>
                    </div>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
      
      <div className="mt-6 bg-yellow-50 border border-yellow-200 p-4 rounded text-sm text-yellow-800">
        <strong>নোট:</strong> বোনাস সেন্ড করার সাথে সাথে এজেন্টের ব্যালেন্সে যোগ হবে এবং ট্রানজেকশন হিস্টোরিতে "Bonus" হিসেবে সেভ থাকবে।
      </div>
    </div>
  );
};

export default MonthlyReport;