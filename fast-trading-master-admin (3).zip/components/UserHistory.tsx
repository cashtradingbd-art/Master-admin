import React, { useState } from 'react';
import { User, Transaction } from '../types';
import { Search, Eye, EyeOff } from 'lucide-react';

interface Props {
  users: User[];
  transactions: Transaction[];
}

const UserHistory: React.FC<Props> = ({ users, transactions }) => {
  const [activeTab, setActiveTab] = useState<'users' | 'transactions'>('users');
  const [searchTerm, setSearchTerm] = useState('');
  const [showPassword, setShowPassword] = useState<Record<string, boolean>>({});

  const togglePassword = (id: string) => {
    setShowPassword(prev => ({...prev, [id]: !prev[id]}));
  };

  const filteredUsers = users.filter(u => 
    u.email.toLowerCase().includes(searchTerm.toLowerCase()) || 
    u.phone.includes(searchTerm)
  );

  return (
    <div className="bg-white rounded-lg shadow overflow-hidden">
      <div className="flex border-b">
        <button 
          className={`px-6 py-3 font-medium ${activeTab === 'users' ? 'border-b-2 border-blue-600 text-blue-600' : 'text-gray-600'}`}
          onClick={() => setActiveTab('users')}
        >
          ইজারা লিস্ট (Users)
        </button>
        <button 
          className={`px-6 py-3 font-medium ${activeTab === 'transactions' ? 'border-b-2 border-blue-600 text-blue-600' : 'text-gray-600'}`}
          onClick={() => setActiveTab('transactions')}
        >
          লেনদেন হিস্টোরি
        </button>
      </div>

      <div className="p-4">
        <div className="mb-4 relative">
          <input 
            type="text" 
            placeholder="Search by Email or Phone..." 
            className="w-full pl-10 pr-4 py-2 border rounded-lg focus:outline-none focus:border-blue-500"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
          <Search className="absolute left-3 top-2.5 text-gray-400" size={20} />
        </div>

        {activeTab === 'users' ? (
          <div className="overflow-x-auto">
            <table className="w-full text-left">
              <thead className="bg-gray-50 text-gray-600 text-sm">
                <tr>
                  <th className="p-3">নাম</th>
                  <th className="p-3">ইমেইল</th>
                  <th className="p-3">পাসওয়ার্ড</th>
                  <th className="p-3">ব্যালেন্স</th>
                  <th className="p-3">ফোন</th>
                  <th className="p-3">জয়েনিং তারিখ</th>
                </tr>
              </thead>
              <tbody className="text-sm">
                {filteredUsers.map(user => (
                  <tr key={user.id} className="border-b hover:bg-gray-50">
                    <td className="p-3 font-medium">{user.name}</td>
                    <td className="p-3 text-blue-600">{user.email}</td>
                    <td className="p-3 flex items-center gap-2">
                      <span className="font-mono bg-gray-100 px-2 py-1 rounded">
                         {/* Note: In real production, never send passwords to frontend */}
                         {user.password}
                      </span>
                    </td>
                    <td className="p-3 font-bold text-green-600">${user.balance.toFixed(2)}</td>
                    <td className="p-3">{user.phone}</td>
                    <td className="p-3 text-gray-500">{user.joinedDate}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left">
              <thead className="bg-gray-50 text-gray-600 text-sm">
                <tr>
                  <th className="p-3">তারিখ</th>
                  <th className="p-3">ব্যবহারকারী</th>
                  <th className="p-3">ধরন</th>
                  <th className="p-3">মেথড</th>
                  <th className="p-3">পরিমাণ</th>
                  <th className="p-3">বিস্তারিত (Trx/Number)</th>
                  <th className="p-3">স্ট্যাটাস</th>
                </tr>
              </thead>
              <tbody className="text-sm">
                {transactions.map(trx => (
                  <tr key={trx.id} className="border-b hover:bg-gray-50">
                    <td className="p-3 text-gray-500">{trx.date}</td>
                    <td className="p-3">{trx.userEmail}</td>
                    <td className="p-3 capitalize">
                      <span className={`px-2 py-1 rounded text-xs ${
                        trx.type === 'deposit' ? 'bg-green-100 text-green-700' : 
                        trx.type === 'withdraw' ? 'bg-red-100 text-red-700' : 'bg-gray-100'
                      }`}>
                        {trx.type}
                      </span>
                    </td>
                    <td className="p-3">{trx.method}</td>
                    <td className="p-3 font-bold">${trx.amount}</td>
                    <td className="p-3 font-mono text-xs">{trx.details}</td>
                    <td className="p-3">
                      <span className={`px-2 py-1 rounded text-xs font-bold ${
                        trx.status === 'approved' ? 'text-green-600' :
                        trx.status === 'rejected' ? 'text-red-600' : 'text-yellow-600'
                      }`}>
                        {trx.status.toUpperCase()}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
};

export default UserHistory;