import { User, Agent, Transaction, DepositMethod, Settings } from '../types';

export const initialUsers: User[] = [
  { id: '1', name: 'Rahim Uddin', email: 'rahim@gmail.com', password: 'pass123(hidden)', balance: 150.50, phone: '01700000001', status: 'active', joinedDate: '2023-10-01' },
  { id: '2', name: 'Karim Mia', email: 'karim@yahoo.com', password: 'securePass!', balance: 20.00, phone: '01800000002', status: 'active', joinedDate: '2023-11-15' },
  { id: '3', name: 'Banned User', email: 'bad@user.com', password: '123456', balance: 0.00, phone: '01900000003', status: 'blocked', joinedDate: '2023-09-01' },
];

export const initialAgents: Agent[] = [
  { id: '101', name: 'Agent Super', phone: '01711111111', password: 'agentpass', balance: 500.00, commissionRate: 20, isActive: true, totalEarned: 1200 },
  { id: '102', name: 'Agent Dhaka', phone: '01822222222', password: 'dhakapass', balance: 600.00, commissionRate: 35, isActive: true, totalEarned: 300 },
];

export const initialTransactions: Transaction[] = [
  { id: 't1', userId: '1', userEmail: 'rahim@gmail.com', type: 'withdraw', amount: 50, date: '2023-12-01', status: 'pending', method: 'Bkash', details: '01700000001' },
  { id: 't2', userId: '2', userEmail: 'karim@yahoo.com', type: 'deposit', amount: 100, date: '2023-12-02', status: 'approved', method: 'Nagad', details: 'TRX123456' },
  { id: 't3', userId: '1', userEmail: 'rahim@gmail.com', type: 'withdraw', amount: 10, date: '2023-12-03', status: 'rejected', method: 'Rocket', details: '01700000001' },
  // Pending deposit for Agent Dhaka (Rocket method)
  { id: 't4', userId: '1', userEmail: 'rahim@gmail.com', type: 'deposit', amount: 500, date: '2023-12-04', status: 'pending', method: 'Rocket', details: 'TRX999999', agentId: '102' },
];

export const initialDepositMethods: DepositMethod[] = [
  { 
    id: 'd1', name: 'Bkash', type: 'Personal', number: '01700000000', minAmount: 500, maxAmount: 25000, 
    instruction: 'Send Money', requirements: ['TrxID'], status: 'active', addedBy: 'admin', audience: 'All' 
  },
  { 
    id: 'd2', name: 'Nagad', type: 'Agent', number: '01800000000', minAmount: 100, maxAmount: 10000, 
    instruction: 'Cash Out', requirements: ['Last 4 Digit'], status: 'active', addedBy: 'admin', audience: 'All' 
  },
  { 
    id: 'd3', name: 'Rocket', type: 'Personal', number: '01900000000', minAmount: 500, maxAmount: 15000, 
    instruction: 'Send Money', requirements: ['TrxID'], status: 'active', addedBy: 'agent', agentName: 'Agent Dhaka', agentId: '102', audience: 'Agents Only' 
  },
  { 
    id: 'd4', name: 'Upay', type: 'Merchant', number: '01600000000', minAmount: 1000, maxAmount: 50000, 
    instruction: 'Payment', requirements: ['TrxID'], status: 'inactive', addedBy: 'admin', audience: 'Users Only' 
  },
];

export const initialSettings: Settings = {
  dollarRate: 115.50,
  noticeText: 'Welcome to Fast Trading. Withdrawals are processed within 24 hours.',
  telegramLink: 'https://t.me/example',
  whatsappLink: 'https://wa.me/1234567890',
  minWithdraw: 10,
  withdrawMethods: ['Bkash', 'Nagad', 'Rocket', 'Binance'],
};