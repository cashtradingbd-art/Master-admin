import { db } from '../firebaseConfig';
import { 
  collection, 
  doc, 
  addDoc, 
  updateDoc, 
  deleteDoc, 
  onSnapshot, 
  query, 
  orderBy,
  setDoc,
  getDoc
} from 'firebase/firestore';
import { User, Agent, Transaction, DepositMethod, Settings } from '../types';

// Collection References
const USERS_COL = 'users';
const AGENTS_COL = 'agents';
const TRANSACTIONS_COL = 'transactions';
const METHODS_COL = 'deposit_methods';
const SETTINGS_COL = 'settings';

// --- Realtime Data Listeners (Hooks) ---

export const subscribeToUsers = (callback: (users: User[]) => void) => {
  const q = query(collection(db, USERS_COL));
  return onSnapshot(q, (snapshot) => {
    const users = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as User));
    callback(users);
  });
};

export const subscribeToAgents = (callback: (agents: Agent[]) => void) => {
  const q = query(collection(db, AGENTS_COL));
  return onSnapshot(q, (snapshot) => {
    const agents = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Agent));
    callback(agents);
  });
};

export const subscribeToTransactions = (callback: (trxs: Transaction[]) => void) => {
  // Sort by date descending (newest first) could be added here
  const q = query(collection(db, TRANSACTIONS_COL)); 
  return onSnapshot(q, (snapshot) => {
    const trxs = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Transaction));
    // Manual sort because dates are strings in this app
    trxs.sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
    callback(trxs);
  });
};

export const subscribeToDepositMethods = (callback: (methods: DepositMethod[]) => void) => {
  const q = query(collection(db, METHODS_COL));
  return onSnapshot(q, (snapshot) => {
    const methods = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as DepositMethod));
    callback(methods);
  });
};

export const subscribeToSettings = (callback: (settings: Settings) => void) => {
  return onSnapshot(doc(db, SETTINGS_COL, 'general'), (docSnap) => {
    if (docSnap.exists()) {
      callback(docSnap.data() as Settings);
    } else {
      // Initialize default settings if not exists
      const defaultSettings: Settings = {
        dollarRate: 115,
        noticeText: 'Welcome',
        telegramLink: '',
        whatsappLink: '',
        minWithdraw: 10,
        withdrawMethods: []
      };
      setDoc(doc(db, SETTINGS_COL, 'general'), defaultSettings);
    }
  });
};

// --- Action Functions ---

// Agents
export const addAgent = async (agent: Omit<Agent, 'id'>) => {
  await addDoc(collection(db, AGENTS_COL), agent);
};

export const updateAgent = async (id: string, data: Partial<Agent>) => {
  await updateDoc(doc(db, AGENTS_COL, id), data);
};

// Users
export const updateUserBalance = async (id: string, newBalance: number) => {
  await updateDoc(doc(db, USERS_COL, id), { balance: newBalance });
};

// Transactions
export const addTransaction = async (transaction: Transaction) => {
  // We use setDoc with specific ID if provided, or addDoc for auto ID
  if (transaction.id && !transaction.id.startsWith('new')) {
     await setDoc(doc(db, TRANSACTIONS_COL, transaction.id), transaction);
  } else {
     // remove ID from object to let firebase generate one if needed, 
     // but here we keep it simple
     await addDoc(collection(db, TRANSACTIONS_COL), transaction);
  }
};

export const updateTransactionStatus = async (id: string, status: 'approved' | 'rejected' | 'pending') => {
  await updateDoc(doc(db, TRANSACTIONS_COL, id), { status });
};

// Deposit Methods
export const addDepositMethod = async (method: Omit<DepositMethod, 'id'>) => {
  await addDoc(collection(db, METHODS_COL), method);
};

export const updateDepositMethod = async (id: string, data: Partial<DepositMethod>) => {
  await updateDoc(doc(db, METHODS_COL, id), data);
};

export const deleteDepositMethod = async (id: string) => {
  await deleteDoc(doc(db, METHODS_COL, id));
};

// Settings
export const updateSettings = async (settings: Settings) => {
  await setDoc(doc(db, SETTINGS_COL, 'general'), settings);
};
